<?php
return array(
  'Send full task description and comments by email' => 'Senden Sie die vollständige Aufgabenbeschreibung und Kommentare per E-Mail',
  'Email subject' => 'E-Mail Betreff',
  'Send to Assignee' => 'An Zuständigen senden',
  'Send to Creator' => 'An Ersteller senden',
  'Send to Both' => 'An beide senden',
  'Include Task Title and ID in subject line?' => 'Titel und ID der Aufgabe in die Betreffzeile aufnehmen?',
  'Task history emailed to the task creator @"%s" with subject "%s".' => 'Der Aufgabenverlauf wurde per E-Mail an @"%s" (Aufgabenersteller) mit dem Betreff "%s" gesendet.',
  'Task history emailed to the task assignee @"%s" with subject "%s".' => 'Der Aufgabenverlauf wurde per E-Mail an @"%s" (Aufgabenverantwortlicher) mit dem Betreff "%s" gesendet.',
);