<?php
return array(
  'Send full task description and comments by email' => 'Send full task description and comments by email',
  'Email subject' => 'Email Subject',
  'Send to Assignee' => 'Send to Assignee',
  'Send to Creator' => 'Send to Creator',
  'Send to Both' => 'Send to Both',
  'Include Task Title and ID in subject line?' => 'Include Task Title and ID in the subject line?',
  'Task history emailed to the task creator @"%s" with subject "%s".' => 'Task history has been emailed to @"%s" (Task Creator) with the subject "%s".',
  'Task history emailed to the task assignee @"%s" with subject "%s".' => 'Task history has been emailed to @"%s" (Task Assignee) with the subject "%s".',
);
