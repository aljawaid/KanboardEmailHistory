<?php
return array(
  'Send full task description and comments by email' => 'Envoyer la description complète de la tâche et les commentaires par e-mail',
  'Email subject' => 'Sujet du Courriel',
  'Send to Assignee' => 'Envoyer au Cessionnaire',
  'Send to Creator' => 'Envoyer au Créateur',
  'Send to Both' => 'Envoyer aux Deux',
  'Include Task Title and ID in subject line?' => 'Inclure le titre et l\'ID de la tâche dans la ligne d\'objet?',
  'Task history emailed to the task creator @"%s" with subject "%s".' => 'L\'historique des tâches a été envoyé par e-mail à @"%s" (Créateur de tâches) avec pour objet "%s".',
  'Task history emailed to the task assignee @"%s" with subject "%s".' => 'L\'historique des tâches a été envoyé par e-mail à @"%s" (Responsable de la tâche) avec le sujet "%s".',
);
