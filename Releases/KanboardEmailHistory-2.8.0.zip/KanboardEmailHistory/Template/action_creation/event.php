<div class="page-header step-2-form">
    <h2><?= t('Select an event for this Automatic Action') ?></h2>
</div>

<?php if ($values['action_name'] == '\Kanboard\Plugin\KanboardEmailHistory\Action\EmailTaskHistory'): ?>
    <form method="post" class="eth-form" action="<?= $this->url->href('EmailHistoryController', 'parameters', array('project_id' => $project['id'], 'plugin' => 'KanboardEmailHistory')) ?>">
        <?= $this->form->csrf() ?>
        <?= $this->form->hidden('action_name', $values) ?>

        <i><?= $this->form->label(t('Selected Action'), 'action_name', array('class="selected-labels"')) ?></i>
        <?= $this->form->select('action_name', $available_actions, $values, array(), array('disabled')) ?>

        <?= $this->form->label(t('Event'), 'event_name', array('class="selected-labels"')) ?>
        <?= $this->form->select('event_name', $events, $values) ?>

        <div class="form-help">
            <?= t('When the selected event occurs execute the corresponding action') ?>
        </div>

        <fieldset class="help-text">
            <legend><?= t('Description') ?></legend>
            <p><?= t('This Automatic Action queues a final report when the task is closed. Each recipient receives the task description and only the comments permitted for that recipient.') ?></p>
            <p><?= t('One standard-visibility audit comment is added for each unique email address accepted by the mail queue.') ?></p>
        </fieldset>

        <?= $this->modal->submitButtons(array(
            'submitLabel' => t('Next step'),
            'cancelLabel' => t('cancel'),
            'color' => 'green-dark',
        )) ?>
    </form>
<?php else: ?>
    <form method="post" action="<?= $this->url->href('ActionCreationController', 'params', array('project_id' => $project['id'])) ?>">
        <?= $this->form->csrf() ?>
        <?= $this->form->hidden('action_name', $values) ?>

        <?= $this->form->label(t('Action'), 'action_name') ?>
        <?= $this->form->select('action_name', $available_actions, $values, array(), array('disabled')) ?>

        <?= $this->form->label(t('Event'), 'event_name') ?>
        <?= $this->form->select('event_name', $events, $values) ?>

        <div class="form-help">
            <?= t('When the selected event occurs execute the corresponding action.') ?>
        </div>

        <?= $this->modal->submitButtons(array(
            'submitLabel' => t('Next step'),
        )) ?>
    </form>
<?php endif ?>
